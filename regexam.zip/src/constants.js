const CONFIG = {
  PORT: 3000,
  DB_URL: 'mongodb://127.0.0.1:27017/second-hand-electronics',
  SECRET: 'c50dab38-b023-4ca6-9046-d3b226a4fea6',
}

module.exports = CONFIG;